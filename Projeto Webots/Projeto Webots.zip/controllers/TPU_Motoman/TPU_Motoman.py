from controller import Robot, Keyboard

# Inicialização do robô e dos motores
robot = Robot()
timestep = int(robot.getBasicTimeStep())

# Inicialização do teclado
keyboard = Keyboard()
keyboard.enable(timestep)

# Função para imprimir instruções de controle
def print_instructions():
    print("Controle de juntas do Robô Motoman MH5F:")
    print("S: Q (Frente), A (Trás)")
    print("L: W (Frente), S (Trás)")
    print("B: E (Frente), D (Trás)")
    print("U: R (Frente), F (Trás)")
    print("R: T (Frente), G (Trás)")
    print("T: Y (Frente), H (Trás)")
    print("Garra: P (Abrir/Fechar)")

# Chamada para imprimir as instruções no início
print_instructions()

# Definindo os motores do robô
motors = []
motor_names = ["Joint1", "Joint2", "Joint3", "Joint4", "Joint5", "Joint6"]

for name in motor_names:
    motor = robot.getDevice(name)
    if motor:
        motor.setPosition(float('inf'))  # Movimento infinito (controle de velocidade)
        motor.setVelocity(0.0)           # Inicializando com velocidade 0
        motors.append(motor)
    else:
        print(f"Motor {name} não encontrado.")

# Definindo os sensores de posição
position_sensors = []
sensor_names = ["Joint1_sensor", "Joint2_sensor", "Joint3_sensor", "Joint4_sensor", "Joint5_sensor", "Joint6_sensor"]

for name in sensor_names:
    sensor = robot.getDevice(name)
    if sensor:
        sensor.enable(timestep)  # Habilita o sensor
        position_sensors.append(sensor)
    else:
        print(f"Sensor {name} não encontrado.")

# Definindo os motores lineares da garra
gripper_1 = robot.getDevice("Joint7_1")
gripper_2 = robot.getDevice("Joint7_2")
gripper_open = False  # Inicialmente a garra está fechada


# Colocando a velocidade máxima do motor
gripper_1.setVelocity(0.03)  
gripper_2.setVelocity(0.03)  

# Lendo as posições mínimas e máximas da garra
gripper_min_position1 = gripper_1.getMinPosition()   # Posição fechada
gripper_max_position1 = gripper_1.getMaxPosition()  # Posição aberta, conforme a imagem

gripper_min_position2 = gripper_2.getMinPosition()   # Posição fechada
gripper_max_position2 = gripper_2.getMaxPosition()  # Posição aberta, conforme a imagem


# Velocidade para movimentar as juntas
max_speed = 1.0

# Funções de movimento MOVEJ (controla por velocidade de juntas)
def move_joints(joint_speeds):
    for i in range(6):
        motors[i].setVelocity(joint_speeds[i])

# Função de leitura do teclado e controle de movimentos
def update_speeds():
    speeds = [0.0] * 6  # Inicializa todas as juntas como paradas

    key = keyboard.getKey()  # Captura o estado atual da tecla pressionada
    if key == ord('Q'):  # Mover Joint1 para frente
        speeds[0] = max_speed
    elif key == ord('A'):  # Mover Joint1 para trás
        speeds[0] = -max_speed

    if key == ord('W'):  # Mover Joint2 para frente
        speeds[1] = max_speed
    elif key == ord('S'):  # Mover Joint2 para trás
        speeds[1] = -max_speed

    if key == ord('E'):  # Mover Joint3 para frente
        speeds[2] = max_speed
    elif key == ord('D'):  # Mover Joint3 para trás
        speeds[2] = -max_speed

    if key == ord('R'):  # Mover Joint4 para frente
        speeds[3] = max_speed
    elif key == ord('F'):  # Mover Joint4 para trás
        speeds[3] = -max_speed

    if key == ord('T'):  # Mover Joint5 para frente
        speeds[4] = max_speed
    elif key == ord('G'):  # Mover Joint5 para trás
        speeds[4] = -max_speed

    if key == ord('Y'):  # Mover Joint6 para frente
        speeds[5] = max_speed
    elif key == ord('H'):  # Mover Joint6 para trás
        speeds[5] = -max_speed
    
    return speeds

# Função para controlar a garra
def control_gripper():
    global gripper_open  # Acessa o estado global da garra
    key = keyboard.getKey()  # Captura a tecla pressionada
    if key == ord('P'):  # Alterna o estado da garra
        gripper_open = not gripper_open
        if gripper_open:
            gripper_1.setPosition(gripper_max_position1)  # Abrir
            gripper_2.setPosition(gripper_min_position2)
        else:
            gripper_1.setPosition(gripper_min_position1)  # Fechar
            gripper_2.setPosition(gripper_max_position2)

# Função para imprimir as posições das juntas
def print_joint_positions():
    print("Posições das Juntas:")
    for i, sensor in enumerate(position_sensors):
        position = sensor.getValue()
        print(f"Joint{i + 1}: {position:.2f}")

# Inicializa a variável do tempo da última impressão
last_print_time = robot.getTime()

# Loop principal de controle
while robot.step(timestep) != -1:
    # Atualiza as velocidades baseado nas teclas pressionadas
    speeds = update_speeds()
    
    # Aplica as velocidades
    move_joints(speeds)
    
    # Controla a garra com a tecla 'P'
    control_gripper()
       
    # Verifica o tempo atual
    current_time = robot.getTime()
    
    # Imprime as posições a cada 2 segundos
    if current_time - last_print_time >= 2.0:  # Verifica se se passaram 2 segundos
        print_joint_positions()
        last_print_time = current_time  # Atualiza o tempo do último print