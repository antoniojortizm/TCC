import sys
import ikpy
from ikpy.chain import Chain
import math
from controller import Supervisor
import time

IKPY_MAX_ITERATIONS = 4

# Inicializa o Supervisor do Webots.
supervisor = Supervisor()
timeStep = int(4 * supervisor.getBasicTimeStep())

# Caminho do arquivo URDF na pasta do projeto do Webots.
urdf_file_path = r'D:\Antonio\OneDrive - Educacional\Ibmec\TCC\Projeto Webots\worlds\Abb teste\tmpubwdqr9b.urdf'

# Cria a cadeia do braço a partir do URDF.
armCadeia = Chain.from_urdf_file(urdf_file_path, active_links_mask=[False, True, True, True, True, True, True, False])

# Inicializa os motores e encoders do braço.
motores = []
for link in armCadeia.links:
    if 'motor' in link.name:
        motor = supervisor.getDevice(link.name)
        motor.setVelocity(1.0)
        position_sensor = motor.getPositionSensor()
        position_sensor.enable(timeStep)
        motores.append(motor)

# Obtém os nós dos alvos e do braço.
alvos = [supervisor.getFromDef(f'P110{i}') for i in range(1, 9)]
braço = supervisor.getSelf()

# Definindo os motores da garra
gripper_1 = supervisor.getDevice("Joint7_1")
gripper_2 = supervisor.getDevice("Joint7_2")
gripper_open = False  # Inicialmente a garra está fechada

# Colocando a velocidade máxima do motor
gripper_1.setVelocity(0.03)  
gripper_2.setVelocity(0.03)  

# Lendo as posições mínimas e máximas da garra
gripper_min_position1 = gripper_1.getMinPosition()   # Posição fechada
gripper_max_position1 = gripper_1.getMaxPosition()   # Posição aberta

gripper_min_position2 = gripper_2.getMinPosition()   # Posição fechada
gripper_max_position2 = gripper_2.getMaxPosition()   # Posição aberta

# Função para controlar a garra
def control_gripper(open_gripper):
    global gripper_open
    if open_gripper:
        gripper_1.setPosition(gripper_max_position1)  # Abrir
        gripper_2.setPosition(gripper_min_position2)
        gripper_open = True
        print("Garra aberta")
    else:
        gripper_1.setPosition(gripper_min_position1)  # Fechar
        gripper_2.setPosition(gripper_max_position2)
        gripper_open = False
        print("Garra fechada")

def mover_para_alvo(posicao_alvo, tipo_movimento="MOVJ"):
    posicao_arm = braço.getPosition()  # Posição do braço

    # Calcula a posição relativa do alvo em relação ao braço.
    x = posicao_alvo[1] - posicao_arm[1]
    y = posicao_alvo[0] - posicao_arm[0]
    z = posicao_alvo[2] - posicao_arm[2]

    print(f'Movendo para posição relativa: x={x}, y={y}, z={z}, tipo={tipo_movimento}')

    # Calcula a cinemática inversa para encontrar as posições articulares.
    posicao_inicial = [0] + [m.getPositionSensor().getValue() for m in motores] + [0]
    resultados_ik = armCadeia.inverse_kinematics([x, y, z], max_iter=IKPY_MAX_ITERATIONS, initial_position=posicao_inicial)

    # Define a posição dos motores.
    for i in range(len(motores)):
        motores[i].setPosition(resultados_ik[i + 1])

    # Verifica se o braço atingiu o alvo (tolerância de 3 cm).
    posicao = armCadeia.forward_kinematics(resultados_ik)
    distancia_quadrada = (posicao[0, 3] - x) ** 2 + (posicao[1, 3] - y) ** 2 + (posicao[2, 3] - z) ** 2
    distancia = math.sqrt(distancia_quadrada)
    print(f'Distância até o alvo: {distancia:.4f} m')

    return distancia < 0.03  # Tolerância de 3 cm

def esperar(tempo):
    tempo_inicial = time.time()
    while time.time() - tempo_inicial < tempo:
        supervisor.step(timeStep)

# Loop principal para mover o braço seguindo a trajetória do código Inform III.
print('Iniciando a trajetória...')
alvos_inform = [
    ("P1101", "MOVJ", True),  # True para abrir a garra
    ("P1102", "MOVJ", None),  # None para não mudar o estado da garra
    ("P1103", "MOVJ", None),
    ("P1104", "MOVL", False),  # False para fechar a garra
    ("P1105", "MOVL", None),
    ("P1106", "MOVJ", None),
    ("P1107", "MOVL", None),
    ("P1108", "MOVL", True),  # Abre a garra
    ("P1107", "MOVJ", None),
    ("P1101", "MOVJ", False)]  # Fecha a garra no final

# Simula a sequência de movimento no Inform III
for i, (alvo_nome, tipo_movimento, garra_estado) in enumerate(alvos_inform):
    alvo_atingido = False
    alvo = supervisor.getFromDef(alvo_nome)
    print(f'Movendo o braço para o {alvo_nome}...')
    # Tenta mover para o alvo até alcançá-lo.
    while not alvo_atingido and supervisor.step(timeStep) != -1:
        alvo_atingido = mover_para_alvo(alvo.getPosition(), tipo_movimento)
    print(f'{alvo_nome} alcançado!')
    # Controla a garra se necessário
    if garra_estado is not None:
        control_gripper(garra_estado)
    # Temporizadores conforme o código Inform III.
    if i == 0:  # Após P1101
        esperar(1.0)
    elif i == 3:  # Após P1104
        esperar(2.0)
    elif i == 7:  # Após P1108
        esperar(3.0)

print('Trajetória completa!')


