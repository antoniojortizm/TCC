import sys
import tempfile
import ikpy
from ikpy.chain import Chain
import math
from controller import Supervisor
import time

IKPY_MAX_ITERATIONS = 4

# Inicializa o Supervisor do Webots.
supervisor = Supervisor()
timeStep = int(4 * supervisor.getBasicTimeStep())

# Caminho do arquivo URDF na pasta do projeto do Webots.
urdf_file_path = r'D:\Antonio\OneDrive - Educacional\Ibmec\TCC\Projeto Webots\Motoman.urdf'  # Certifique-se de que o caminho está correto

# Cria a cadeia do braço a partir do URDF.
armCadeia = Chain.from_urdf_file(urdf_file_path, active_links_mask=[False, True, True, True, True, True, True, False, False])

# Inicializa os motores e encoders do braço Motoman MH5F.
motor_names = ["Joint1", "Joint2", "Joint3", "Joint4", "Joint5", "Joint6"]
motores = []
for name in motor_names:
    motor = supervisor.getDevice(name)
    motor.setVelocity(1.0)
    position_sensor = motor.getPositionSensor()
    position_sensor.enable(timeStep)
    motores.append(motor)

# Obtém os nós do braço e dos alvos.
alvo = supervisor.getFromDef('TARGET')
alvo2 = supervisor.getFromDef('TARGET2')
braço = supervisor.getSelf()

def mover_para_alvo(posicao_alvo):
    # Obtém a posição absoluta do alvo e da base do braço.
    posicao_arm = braço.getPosition()

    # Calcula a posição do alvo em relação ao braço.
    x = -(posicao_alvo[1] - posicao_arm[1])
    y = posicao_alvo[0] - posicao_arm[0]
    z = posicao_alvo[2] - posicao_arm[2]

    # Chama o "ikpy" para calcular a cinemática inversa do braço.
    posicao_inicial = [0] + [m.getPositionSensor().getValue() for m in motores] + [0]
    resultados_ik = armCadeia.inverse_kinematics([x, y, z], max_iter=IKPY_MAX_ITERATIONS, initial_position=posicao_inicial)

    # Aciona os motores do braço com os resultados da IK.
    for i in range(len(motores)):
        motores[i].setPosition(resultados_ik[i + 1])

    # Verifica se o braço chegou ao alvo.
    posicao = armCadeia.forward_kinematics(resultados_ik)
    distancia_quadrada = (posicao[0, 3] - x)**2 + (posicao[1, 3] - y)**2 + (posicao[2, 3] - z)**2
    return math.sqrt(distancia_quadrada) < 0.03  # Tolerância de 3cm

# Loop principal
print('Movendo o braço para o ALVO...')
alvo_atingido = False
alvo2_atingido = False
tempo_alvo_atingido = None  # Tempo de alcance do primeiro alvo
tempo_espera_segundos = 3     # Tempo de espera no primeiro alvo

while supervisor.step(timeStep) != -1:
    if not alvo_atingido:
        # Movendo até o ALVO
        alvo_atingido = mover_para_alvo(alvo.getPosition())
        if alvo_atingido:
            print('ALVO alcançado!')
            tempo_alvo_atingido = time.time()  # Registra o tempo de alcance do primeiro alvo
    elif tempo_alvo_atingido and (time.time() - tempo_alvo_atingido) < tempo_espera_segundos:
        # Espera por alguns segundos no ALVO
        print(f'Aguardando {tempo_espera_segundos} segundos no ALVO...')
    elif not alvo2_atingido:
        # Depois de esperar, move até o ALVO2
        print('Movendo o braço para o ALVO2...')
        alvo2_atingido = mover_para_alvo(alvo2.getPosition())
        if alvo2_atingido:
            print('ALVO2 alcançado!')
            break
